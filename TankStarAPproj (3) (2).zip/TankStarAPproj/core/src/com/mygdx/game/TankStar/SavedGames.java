package com.mygdx.game.TankStar;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.utils.ScreenUtils;

public class SavedGames implements Screen {
    final TankStar game;

    private Texture tankimage1;
    private TextureRegion backgroundTexturetank1;

    private Texture game1;
    private TextureRegion game1Texture;

    private Texture game2;
    private TextureRegion game2Texture;


    private Texture game3;
    private TextureRegion game3Texture;

    private Texture savedGamesTxt;
    private TextureRegion savedGamesTxtTexture;

    OrthographicCamera camera;

    public SavedGames(final TankStar game) {
        this.game = game;
        tankimage1=new Texture(Gdx.files.internal("tankbg.png"));
        backgroundTexturetank1 = new TextureRegion(tankimage1, 0,0,500, 350);

        game1=new Texture(Gdx.files.internal("GAME1.png"));
        game1Texture = new TextureRegion(game1, 0,0,500, 350);

        game2=new Texture(Gdx.files.internal("GAME2.png"));
        game2Texture = new TextureRegion(game2, 0,0,500, 350);

        game3=new Texture(Gdx.files.internal("GAME3.png"));
        game3Texture = new TextureRegion(game3, 0,0,500, 350);

        savedGamesTxt=new Texture(Gdx.files.internal("savedgamestxt.png"));
        savedGamesTxtTexture = new TextureRegion(savedGamesTxt, 0,0,500, 350);

        camera = new OrthographicCamera();
        camera.setToOrtho(false, 800, 480);
    }

    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(Color.valueOf("#faf7c9"));

        camera.update();
        game.batch.setProjectionMatrix(camera.combined);

        game.batch.begin();
        game.batch.setColor(0.5F,0.5F,0.5F,1F);
        game.batch.draw(backgroundTexturetank1, 0,0, 800, 480);

        game.batch.setColor(1F,1F,1F,1F);
//        game.font.setColor(Color.valueOf("#8c42ed"));
//        game.font.getData().setScale(2);
//        game.font.draw(game.batch, "SAVED GAMES", 300, 450);
        game.batch.draw(savedGamesTxtTexture, 100,200);
        game.batch.draw(game1Texture, -175,0, 450, 270);
        game.batch.draw(game2Texture, 90,0, 450, 270);
        game.batch.draw(game3Texture, 355,0, 450, 270);
//        game.font.draw(game.batch, "Press 1 to begin!", 250, 300);
        game.batch.end();

        if (Gdx.input.isKeyPressed(Input.Keys.NUM_6)) {
            game.setScreen(new WinLose(game));
            dispose();
        }
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }

}
