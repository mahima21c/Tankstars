package com.mygdx.game.TankStar;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.utils.ScreenUtils;

public class pauseScreen  implements Screen {
    final TankStar game;
    private Texture backgroundImage;
    private TextureRegion backgroundTexture;

    private Texture terrain;
    private TextureRegion terrainTexture;

    private Texture tank1;
    private TextureRegion tank1Texture;

    private Texture tank2;
    private TextureRegion tank2Texture;

    private Texture health;
    private TextureRegion healthTexture;

    private Texture angle;
    private TextureRegion angleTexture;

    private Texture fire;
    private TextureRegion fireTexture;

    private Texture navigate;
    private TextureRegion navigateTexture;

    private Texture pause;
    private TextureRegion pauseTexture;

    private Texture pausebg;
    private TextureRegion pausebgTexture;

    private Texture save;
    private TextureRegion saveTexture;

    private Texture resume;
    private TextureRegion resumeTexture;

    private Texture exit;
    private TextureRegion exitTexture;
    OrthographicCamera camera;

    public pauseScreen(final TankStar game) {
        this.game=game;
        backgroundImage = new Texture(Gdx.files.internal("skybg.jpeg"));
        backgroundTexture = new TextureRegion(backgroundImage, 0, 0, 600, 700);

        terrain = new Texture(Gdx.files.internal("terrain.png"));
        terrainTexture = new TextureRegion(terrain, 0, 0, 600, 700);

        tank1 = new Texture(Gdx.files.internal("tank1.png"));
        tank1Texture = new TextureRegion(tank1, 0, 0, 1400, 1400);

        tank2 = new Texture(Gdx.files.internal("tank2.png"));
        tank2Texture = new TextureRegion(tank2, 0, 0, 1400, 1400);
        tank2Texture.flip(true,false);

        health = new Texture(Gdx.files.internal("health.png"));
        healthTexture = new TextureRegion(health, 0, 0, 1400, 1400);

        angle = new Texture(Gdx.files.internal("angleChange.png"));
        angleTexture = new TextureRegion(angle, 0, 0, 1400, 1400);

        fire = new Texture(Gdx.files.internal("FIRE.png"));
        fireTexture = new TextureRegion(fire, 0, 0, 1400, 1400);

        navigate = new Texture(Gdx.files.internal("navigate.png"));
        navigateTexture = new TextureRegion(navigate, 0, 0, 1400, 1400);

        pause = new Texture(Gdx.files.internal("pause.png"));
        pauseTexture = new TextureRegion(pause, 0, 0, 1400, 1400);

        pausebg = new Texture(Gdx.files.internal("pausebg.png"));
        pausebgTexture = new TextureRegion(pausebg, 0, 0, 1400, 1400);

        save = new Texture(Gdx.files.internal("SAVEGAME.png"));
        saveTexture = new TextureRegion(save, 0, 0, 1400, 1400);

        resume = new Texture(Gdx.files.internal("RESUMEGAME.png"));
        resumeTexture = new TextureRegion(resume, 0, 0, 1400, 1400);

        exit = new Texture(Gdx.files.internal("EXITGAME.png"));
        exitTexture = new TextureRegion(exit, 0, 0, 1400, 1400);

        camera = new OrthographicCamera();
        camera.setToOrtho(false, 800, 480);
    }


    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0, 0);

        camera.update();
        game.batch.setProjectionMatrix(camera.combined);

        game.batch.begin();
        game.batch.setColor(0.5F,0.5F,0.5F,1F);     //darkens screen
        game.batch.draw(backgroundTexture, 0,0, 800, 480);
        game.batch.draw(terrainTexture, 0,-650, 1000, 1100);
        game.batch.draw(tank1Texture, 210,-350, 800, 700);
        game.batch.draw(tank2Texture, 285,-122, 400, 400);
        game.batch.draw(healthTexture, 210,-200, 700, 700);
        game.batch.draw(fireTexture, 420,-540, 700, 700);
        game.batch.draw(pauseTexture, -35,80, 400, 400);

        game.batch.setColor(0.5F,0.5F,0.5F,0.5F);        //reduce opacity
        game.batch.draw(navigateTexture, -70,-530, 700, 700);
        game.batch.draw(angleTexture, 540,-540, 700, 700);

        game.batch.setColor(1F,1F,1F,1F);     //brightens screen
        game.batch.draw(pausebgTexture, 38,-1090, 1550, 1550);
        game.batch.draw(saveTexture, 220,-320, 800, 800);
        game.batch.draw(resumeTexture, 290,-360, 770, 770);
        game.batch.draw(exitTexture, 290,-480, 770, 770);
        game.batch.end();

        if (Gdx.input.isKeyPressed(Input.Keys.NUM_5)) {
            game.setScreen(new SavedGames(game));
            dispose();
        }
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }

}
