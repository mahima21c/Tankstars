package com.mygdx.game.TankStar;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.utils.ScreenUtils;
public class MainMenu implements Screen {

    final TankStar game;
    private Texture backgroundImage;
    private TextureRegion backgroundTexture;

    private Texture welcome;
    private TextureRegion welcomeTexture;

    private Texture begintxt;
    private TextureRegion begintxtTexture;
    OrthographicCamera camera;

    public MainMenu(final TankStar game) {
        this.game = game;
        backgroundImage = new Texture(Gdx.files.internal("tankbg.png"));
        backgroundTexture = new TextureRegion(backgroundImage, 0, 0, 500, 350);

        welcome = new Texture(Gdx.files.internal("welcometxt.png"));
        welcomeTexture = new TextureRegion(welcome, 0, 0, 1000, 500);

        begintxt = new Texture(Gdx.files.internal("begintxt.png"));
        begintxtTexture = new TextureRegion(begintxt, 0, 0, 1000, 500);
        camera = new OrthographicCamera();
        camera.setToOrtho(false, 800, 480);
    }
    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0, 0);

        camera.update();
        game.batch.setProjectionMatrix(camera.combined);

        game.batch.begin();
        game.batch.draw(backgroundTexture, 0,0, 800, 480);
        game.batch.draw(welcomeTexture,  70, 50);
        game.batch.draw(begintxtTexture,  70, -10);
//        game.font.setColor(Color.valueOf("#8c42ed"));
//        game.font.getData().setScale(2);
//
//        game.font.draw(game.batch, "Welcome to Tank Stars!", 250, 400);
//        game.font.draw(game.batch, "Press enter to begin!", 250, 300);
        game.batch.end();

        if (Gdx.input.isKeyPressed(Input.Keys.ENTER)) {
            game.setScreen(new FrontPage(game));
            dispose();
        }
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }

}
