package com.mygdx.game.TankStar;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.IntMap;
import com.badlogic.gdx.utils.ScreenUtils;

public class GamePage implements Screen {
    final TankStar game;
    private Texture backgroundImage;
    private TextureRegion backgroundTexture;

    private Texture terrain;
    private TextureRegion terrainTexture;

    private Texture tank1;
    private TextureRegion tank1Texture;

    private Texture tank2;
    private TextureRegion tank2Texture;

    private Texture health;
    private TextureRegion healthTexture;

    private Texture angle;
    private TextureRegion angleTexture;

    private Texture fire;
    private TextureRegion fireTexture;

    private Texture navigate;
    private TextureRegion navigateTexture;

    private Texture pause;
    private TextureRegion pauseTexture;

    Rectangle tankk1;

    OrthographicCamera camera;

    public GamePage(final TankStar game) {
        this.game = game;
        backgroundImage = new Texture(Gdx.files.internal("skybg.jpeg"));
        backgroundTexture = new TextureRegion(backgroundImage, 0, 0, 600, 700);

        terrain = new Texture(Gdx.files.internal("terrain.png"));
        terrainTexture = new TextureRegion(terrain, 0, 0, 600, 700);

        tank1 = new Texture(Gdx.files.internal("tank1.png"));
        tank1Texture = new TextureRegion(tank1, 0, 0, 1400, 1400);

        tank2 = new Texture(Gdx.files.internal("tank2.png"));
        tank2Texture = new TextureRegion(tank2, 0, 0, 1400, 1400);
        tank2Texture.flip(true,false);

        health = new Texture(Gdx.files.internal("health.png"));
        healthTexture = new TextureRegion(health, 0, 0, 1400, 1400);

        angle = new Texture(Gdx.files.internal("angleChange.png"));
        angleTexture = new TextureRegion(angle, 0, 0, 1400, 1400);

        fire = new Texture(Gdx.files.internal("FIRE.png"));
        fireTexture = new TextureRegion(fire, 0, 0, 1400, 1400);

        navigate = new Texture(Gdx.files.internal("navigate.png"));
        navigateTexture = new TextureRegion(navigate, 0, 0, 1400, 1400);

        pause = new Texture(Gdx.files.internal("pause.png"));
        pauseTexture = new TextureRegion(pause, 0, 0, 1400, 1400);

        camera = new OrthographicCamera();
        camera.setToOrtho(false, 800, 480);

        tankk1 =new Rectangle();
        tankk1.x=210;
        tankk1.y=-350;
        tankk1.width=64;
        tankk1.height=64;
    }


    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0, 0);

        camera.update();
        game.batch.setProjectionMatrix(camera.combined);

        game.batch.begin();
//        game.batch.draw(terrainTexture, 0,0, 1000, 400);
        game.batch.setColor(1,1,1,1F);
        game.batch.draw(backgroundTexture, 0,0, 800, 480);
        game.batch.draw(terrainTexture, 0,-650, 1000, 1100);
        game.batch.draw(tank1Texture, 210,-350, 800, 700);
        game.batch.draw(tank2Texture, 285,-122, 400, 400);
        game.batch.draw(healthTexture, 210,-200, 700, 700);
        game.batch.draw(fireTexture, 420,-540, 700, 700);
        game.batch.draw(pauseTexture, -35,80, 400, 400);

        game.batch.setColor(1,1,1,0.5F);        //reduce opacity
        game.batch.draw(navigateTexture, -70,-530, 700, 700);
        game.batch.draw(angleTexture, 540,-540, 700, 700);
        game.batch.draw(tank1Texture, tankk1.x, tankk1.y, tankk1.width, tankk1.height);
        game.batch.end();

        if (Gdx.input.isKeyPressed(Input.Keys.NUM_4)) {
            game.setScreen(new pauseScreen(game));
            dispose();
        }
//
//        if (Gdx.input.isTouched()) {
//            Vector3 touchPos=new Vector3();
//            touchPos.set(Gdx.input.getX(),Gdx.input.getY(),0);
//            camera.unproject(touchPos);
//            tankk1.x=touchPos.x;}
        if (Gdx.input.isKeyPressed(Input.Keys.LEFT)){
            tankk1.x-=200*Gdx.graphics.getDeltaTime();
        }
        if (Gdx.input.isKeyPressed(Input.Keys.RIGHT))
            tankk1.x+=200*Gdx.graphics.getDeltaTime();
        if (tankk1.x<0) {
            tankk1.x = 0;
        }
        if (tankk1.x>1000){
            tankk1.x=0;
        }
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }

}
