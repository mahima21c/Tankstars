package com.mygdx.game.TankStar;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.utils.ScreenUtils;

public class WinLose implements Screen {
    final TankStar game;
    private Texture backgroundImage;
    private TextureRegion backgroundTexture;

    private Texture youWin;
    private TextureRegion youWinTexture;

    private Texture youLose;
    private TextureRegion youLoseTexture;

    private Texture tank1;
    private TextureRegion tank1Texture;

    private Texture tank3;
    private TextureRegion tank3Texture;
    OrthographicCamera camera;

    public WinLose(final TankStar game) {
        this.game = game;
        backgroundImage = new Texture(Gdx.files.internal("tankbg.png"));
        backgroundTexture = new TextureRegion(backgroundImage, 0, 0, 500, 350);

        youWin = new Texture(Gdx.files.internal("youWin.png"));
       youWinTexture = new TextureRegion(youWin, 0, 0, 1000, 500);

        youLose = new Texture(Gdx.files.internal("youLose.png"));
        youLoseTexture = new TextureRegion(youLose, 0, 0, 1000, 500);

        tank1 = new Texture(Gdx.files.internal("tank1.png"));
        tank1Texture = new TextureRegion(tank1, 0, 0, 700, 490);

        tank3 = new Texture(Gdx.files.internal("tank3.png"));
        tank3Texture = new TextureRegion(tank3, 0, 0, 700, 490);
        camera = new OrthographicCamera();
        camera.setToOrtho(false, 800, 480);
    }
    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0, 0);

        camera.update();
        game.batch.setProjectionMatrix(camera.combined);

        game.batch.begin();
        game.batch.setColor(0.3F,0.3F,0.3F,0.5F);     //darkens screen
        game.batch.draw(backgroundTexture, 0,0, 800, 480);
        game.batch.setColor(1F,1F,1F,1F);     //brightens screen

        game.batch.draw(tank1Texture, 20,-330, 900, 700);
        game.batch.draw(tank3Texture, 470,-90, 550, 420);
        game.batch.draw(youWinTexture,  -170, 50);
        game.batch.draw(youLoseTexture,  300, 50);
//        game.font.setColor(Color.valueOf("#8c42ed"));
//        game.font.getData().setScale(2);
//
//        game.font.draw(game.batch, "Welcome to Tank Stars!", 250, 400);
//        game.font.draw(game.batch, "Press enter to begin!", 250, 300);
        game.batch.end();

        if (Gdx.input.isKeyPressed(Input.Keys.ENTER)) {
            game.setScreen(new FrontPage(game));
            dispose();
        }
        if (Gdx.input.isKeyPressed(Input.Keys.ESCAPE)) {
            Gdx.app.exit();
            dispose();
        }
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
