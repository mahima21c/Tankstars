package com.mygdx.game.TankStar;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.ScreenUtils;

public class FrontPage implements Screen {
    final TankStar game;
    private Texture buttonimage;
    private Texture resumeimage;
    private Texture endimage;
    private Texture tankimage1;
    private TextureRegion backgroundTexturetank1;
    private TextureRegion backgroundTexture;
    private TextureRegion backgroundTexture2;
    private TextureRegion backgroundTexture3;

    Rectangle newbutton;
    Rectangle resumebutton;

    private Texture pausebg;
    private TextureRegion pausebgTexture;
    OrthographicCamera camera;

    public FrontPage(final TankStar game) {
        this.game = game;
        buttonimage = new Texture(Gdx.files.internal("NEW_GAME.png"));
        backgroundTexture = new TextureRegion(buttonimage, 0,0,3*Gdx.graphics.getWidth()/2, 3*Gdx.graphics.getHeight()/2);
        resumeimage=new Texture(Gdx.files.internal("RESUMEGAME.png"));
        backgroundTexture2 = new TextureRegion(resumeimage, 0,0,3*Gdx.graphics.getWidth()/2, 3*Gdx.graphics.getHeight()/2);
        endimage=new Texture(Gdx.files.internal("EXITGAME.png"));
        backgroundTexture3 = new TextureRegion(endimage, 0,0,3*Gdx.graphics.getWidth()/2, 3*Gdx.graphics.getHeight()/2);
        tankimage1=new Texture(Gdx.files.internal("tankbg.png"));
        backgroundTexturetank1 = new TextureRegion(tankimage1, 0,0,500, 350);
        pausebg = new Texture(Gdx.files.internal("pausebg.png"));
        pausebgTexture = new TextureRegion(pausebg, 0, 0, 1400, 1400);

        camera = new OrthographicCamera();
        camera.setToOrtho(false, 800, 480);

        newbutton=new Rectangle();
        newbutton.x=320;
        newbutton.y=-240;
        newbutton.width=770;
        newbutton.height=770;

        resumebutton=new Rectangle();
        resumebutton.x=320;
        resumebutton.y=-360;
        resumebutton.height=770;
        resumebutton.width=770;

    }


    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(Color.valueOf("#faf7c9"));

        camera.update();
        game.batch.setProjectionMatrix(camera.combined);

        game.batch.begin();
        game.batch.draw(backgroundTexturetank1, 0,0, 800, 480);

        game.batch.setColor(1F ,1F,1F,0.7F);
        game.batch.draw(pausebgTexture, 38,-1110, 1550, 1550);

        game.batch.setColor(1F ,1F,1F,1F);
        game.batch.draw(backgroundTexture, 320,-240, 770, 770);
        game.batch.draw(backgroundTexture2, 320,-360, 770, 770);
        game.batch.draw(backgroundTexture3, 320,-480, 770, 770);

        game.font.setColor(250,247,201,255);
        game.font.getData().setScale(2);

        game.batch.draw(backgroundTexture,newbutton.x,newbutton.y,newbutton.width,newbutton.height);
        game.batch.draw(backgroundTexture2,resumebutton.x,resumebutton.y,resumebutton.width,resumebutton.height);
        game.batch.end();

//        if (Gdx.input.isKeyPressed(Input.Keys.NUM_1)) {
//            game.setScreen(new ChooseTank1(game));
//            dispose();
//        }

        if (Gdx.input.isKeyPressed(Input.Keys.NUM_3)) {
            Gdx.app.exit();
            dispose();
        }
        if (Gdx.input.isKeyPressed(Input.Keys.NUM_2)) {
            game.setScreen(new SavedGames(game));
            dispose();
        }
        if (Gdx.input.isTouched()){
            Vector3 touchPos=new Vector3();
            touchPos.set(Gdx.input.getX(),Gdx.input.getY(),0);
            camera.unproject(touchPos);
            if (touchPos.x>= 320 && touchPos.x<=320+770 && touchPos.y>= 770-770f/1.5f && touchPos.y<=770+770f/1.5f){
                game.setScreen(new ChooseTank1(game));
            }
        }
        else if (Gdx.input.isTouched()) {
            Vector3 touchPos1=new Vector3();
            touchPos1.set(Gdx.input.getX(),Gdx.input.getY(),0);
            camera.unproject(touchPos1);
            if (touchPos1.x>=320 && touchPos1.x<=320+770 && touchPos1.y>=770-770f/4f && touchPos1.y<=770+770f/2){
                game.setScreen(new SavedGames(game));
            }
        }


    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
