package com.mygdx.game.TankStar;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.utils.ScreenUtils;

public class ChooseTank1 implements Screen {
    final TankStar game;
    private Texture tank1;
    private TextureRegion tank1Texture;

    private Texture tank2;
    private TextureRegion tank2Texture;

    private Texture tank3;
    private TextureRegion tank3Texture;

    private Texture choose1;
    private TextureRegion choose1Texture;
    OrthographicCamera camera;

    public ChooseTank1(final TankStar game) {
        this.game = game;
        tank1 = new Texture(Gdx.files.internal("tank1.png"));
        tank1Texture = new TextureRegion(tank1, 0, 0, 700, 490);
        tank2 = new Texture(Gdx.files.internal("tank2.png"));
        tank2Texture = new TextureRegion(tank2, 0, 0, 700, 490);
        tank3 = new Texture(Gdx.files.internal("tank3.png"));
        tank3Texture = new TextureRegion(tank3, 0, 0, 700, 490);
        choose1 = new Texture(Gdx.files.internal("choose1.png"));
        choose1Texture = new TextureRegion(choose1, 0, 0, 700, 490);

        camera = new OrthographicCamera();
        camera.setToOrtho(false, 800, 480);
    }

    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(Color.valueOf("#faf7c9"));

        camera.update();
        game.batch.setProjectionMatrix(camera.combined);

        game.batch.begin();
        game.batch.draw(tank1Texture, 0,-300, 900, 700);
        game.batch.draw(tank2Texture, ((float)Gdx.graphics.getWidth()/(6)),100, 400, 280);
        game.batch.draw(tank3Texture, 520,-55, 550, 420);
        game.batch.draw(choose1Texture,  70, 50);
//        game.font.setColor(Color.valueOf("#8c42ed"));
//        game.font.getData().setScale(2);
//        game.font.draw(game.batch, "Player 1 Choose Your Tank!", 250, 470);
//        game.font.draw(game.batch, "Press enter to begin!", 250, 300);
        game.batch.end();

        if (Gdx.input.isKeyPressed(Input.Keys.NUM_2)) {
            game.setScreen(new ChooseTank2(game));
            dispose();
        }
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}

